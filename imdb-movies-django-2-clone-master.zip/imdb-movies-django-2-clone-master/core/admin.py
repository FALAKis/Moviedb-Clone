from django.contrib import admin
from core.models import Movie, MovieImage


admin.site.register(Movie)
admin.site.register(MovieImage)
